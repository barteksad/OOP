public class SzczepB extends Szczepionka
{
    public SzczepB()
    {
        super("SzczepB", "Firma B", 15);
    }
}