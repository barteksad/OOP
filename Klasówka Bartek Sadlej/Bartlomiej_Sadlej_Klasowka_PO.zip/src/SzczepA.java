public class SzczepA extends Szczepionka
{
    public SzczepA()
    {
        super("SzczepA", "Firma A", 5);
    }
}