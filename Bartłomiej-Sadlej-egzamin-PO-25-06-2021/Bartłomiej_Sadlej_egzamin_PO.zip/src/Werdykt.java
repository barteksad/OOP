public enum Werdykt {
    umorzenie,
    przyznanie_winy,
    uniewinnienie;
}
