public interface Stack
{
    public void push(int x);

    public int pop();
    
    public void or();

    public void and();

    public void xor();

    public void complement();
}