package zad1;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.TreeSet;

public class Parametry {
    private static int liczba_parametrów = 17;
    private static TreeSet<Character> dozwolone_ruchy = new TreeSet<Character>(Arrays.asList('l', 'p', 'i', 'w', 'j'));

    private int ile_tur;
    private int rozmiar_planszy_x;
    private int rozmiar_planszy_y;
    private int pocz_ile_robów;
    private ArrayList<Character> pocz_progr;
    private ArrayList<Character> spis_instr;
    private float pocz_energia;
    private float ile_daje_jedzenie;
    private int ile_rośnie_jedzenie;
    private float koszt_tury;
    private float pr_powielenia;
    private float ułamek_energii_rodzica;
    private float pr_usunięcia_instr;
    private float pr_dodania_instr;
    private float pr_zmiany_instr;
    private float limit_powielania;
    private int co_ile_wypisz;

    public Parametry(String ścierzka) {
        Scanner scanner = null;
        try {
            scanner = new Scanner(new File(ścierzka));
        } catch (Exception e) {
            System.out.println("Zła ścierzka do pliku z parametrami!\n" + e);
            System.exit(1);
        }

        TreeSet<String> wczytane_parametry = new TreeSet<String>();

        try {
            while (scanner.hasNextLine()) {
                String linia = scanner.nextLine();
                Scanner skan_lini = new Scanner(linia);
                String parametr = skan_lini.next();
                int ile_wczytano = parametr.length();

                if (wczytane_parametry.contains(parametr))
                    throw new InputMismatchException();
                wczytane_parametry.add(parametr);

                if (parametr.equals("pocz_progr")) {
                    this.sprawdźUstawPoczProgr(skan_lini);
                    ile_wczytano += pocz_progr.size() * 2 - 1;
                } else if (parametr.equals("spis_instr")) {
                    this.sprawdźUstawSpisInstr(skan_lini);
                    ile_wczytano += spis_instr.size() * 2 - 1;
                } else {
                    ile_wczytano += this.sprawdźUstawParametr(parametr, skan_lini);
                }
                if (ile_wczytano + 1 != linia.length())
                    throw new InputMismatchException();
            }
            if (wczytane_parametry.size() != Parametry.liczba_parametrów)
                throw new InputMismatchException();
            if (!spis_instr.containsAll(pocz_progr))
                throw new InputMismatchException();
        } catch (Exception e) {
            System.out.println("Zły format pliku z parametrami!\n" + e);
            System.exit(1);
        }
    }

    private void sprawdźUstawPoczProgr(Scanner scanner) {
        pocz_progr = new ArrayList<Character>();
        String input = scanner.nextLine();
        boolean spacja = true;

        for (int i = 0; i < input.length(); i++) {
            if (!(input.charAt(i) == ' ' ^ spacja)) {
                spacja = !spacja;
                if (!spacja)
                    continue;
                if (!Parametry.dozwolone_ruchy.contains(input.charAt(i)))
                    throw new InputMismatchException();
                    pocz_progr.add(input.charAt(i));
            } else
                throw new InputMismatchException();
        }
        if (spacja == false)
            throw new InputMismatchException();
    }

    private void sprawdźUstawSpisInstr(Scanner scanner) {
        spis_instr = new ArrayList<Character>();
        String input = scanner.nextLine();
        boolean spacja = true;

        for (int i = 0; i < input.length(); i++) {
            char nowy = input.charAt(i);
            if (!(nowy == ' ' ^ spacja)) {
                spacja = !spacja;
                if (!spacja)
                    continue;
                if (!Parametry.dozwolone_ruchy.contains(nowy) || spis_instr.contains(nowy))
                    throw new InputMismatchException();
                spis_instr.add(nowy);
            } else
                throw new InputMismatchException();
        }
        if (spacja == false)
            throw new InputMismatchException();
    }

    private int sprawdźUstawParametr(String parametr, Scanner skan_lini) {
        int wartość_int = -1;
        float wartość_float = -1;
        String tmp = "";

        switch (parametr) {

            case "ile_tur":
                if ((wartość_int = skan_lini.nextInt()) < 0)
                    throw new InputMismatchException();
                ile_tur = wartość_int;
                break;

            case "rozmiar_planszy_x":
                if ((wartość_int = skan_lini.nextInt()) <= 0)
                    throw new InputMismatchException();
                rozmiar_planszy_x = wartość_int;
                break;

            case "rozmiar_planszy_y":
                if ((wartość_int = skan_lini.nextInt()) <= 0)
                    throw new InputMismatchException();
                rozmiar_planszy_y = wartość_int;
                break;

            case "pocz_ile_robów":
                if ((wartość_int = skan_lini.nextInt()) < 0)
                    throw new InputMismatchException();
                pocz_ile_robów = wartość_int;
                break;

            case "ile_daje_jedzenie":
                tmp = skan_lini.next();
                wartość_float = Float.parseFloat(tmp);
                if (wartość_float < 0)
                    throw new InputMismatchException();
                ile_daje_jedzenie = wartość_float;
                break;

            case "ile_rośnie_jedzenie":
                if ((wartość_int = skan_lini.nextInt()) < 0)
                    throw new InputMismatchException();
                ile_rośnie_jedzenie = wartość_int;
                break;

            case "koszt_tury":
                tmp = skan_lini.next();
                wartość_float = Float.parseFloat(tmp);
                if (wartość_float < 0)
                    throw new InputMismatchException();
                koszt_tury = wartość_float;
                break;

            case "pocz_energia":
                tmp = skan_lini.next();
                wartość_float = Float.parseFloat(tmp);
                if (wartość_float < 0)
                    throw new InputMismatchException();
                pocz_energia = wartość_float;
                break;

            case "pr_powielenia":
                tmp = skan_lini.next();
                wartość_float = Float.parseFloat(tmp);
                if (wartość_float < 0 || wartość_float > 1)
                    throw new InputMismatchException();
                koszt_tury = wartość_float;
                break;

            case "ułamek_energii_rodzica":
                tmp = skan_lini.next();
                wartość_float = Float.parseFloat(tmp);
                if (wartość_float < 0 || wartość_float > 1)
                    throw new InputMismatchException();
                ułamek_energii_rodzica = wartość_float;
                break;

            case "pr_usunięcia_instr":
                tmp = skan_lini.next();
                wartość_float = Float.parseFloat(tmp);
                if (wartość_float < 0 || wartość_float > 1)
                    throw new InputMismatchException();
                pr_usunięcia_instr = wartość_float;
                break;

            case "pr_dodania_instr":
                tmp = skan_lini.next();
                wartość_float = Float.parseFloat(tmp);
                if (wartość_float < 0 || wartość_float > 1)
                    throw new InputMismatchException();
                pr_dodania_instr = wartość_float;
                break;

            case "pr_zmiany_instr":
                tmp = skan_lini.next();
                wartość_float = Float.parseFloat(tmp);
                if (wartość_float < 0 || wartość_float > 1)
                    throw new InputMismatchException();
                pr_zmiany_instr = wartość_float;
                break;

            case "limit_powielania":
                tmp = skan_lini.next();
                wartość_float = Float.parseFloat(tmp);
                limit_powielania = wartość_float;
                break;

            case "co_ile_wypisz":
                if ((wartość_int = skan_lini.nextInt()) < 0)
                    throw new InputMismatchException();
                co_ile_wypisz = wartość_int;
                break;
            default:
                throw new InputMismatchException();
        }
        if (wartość_int == -1)
            return tmp.length();
        else
            return ("" + wartość_int).length();
    }

    public int ile_tur() {
        return ile_tur;
    }

    public int rozmiar_planszy_x() {
        return rozmiar_planszy_x;
    }

    public int rozmiar_planszy_y() {
        return rozmiar_planszy_y;
    }

    public int pocz_ile_robów() {
        return pocz_ile_robów;
    }

    public ArrayList<Character> pocz_progr() {
        ArrayList<Character> kopia = new ArrayList<Character>();
        for (char c : pocz_progr)
            kopia.add(c);
        return kopia;
    }

    public ArrayList<Character> spis_instr() {
        return spis_instr;
    }

    public float pocz_energia() {
        return pocz_energia;
    }

    public float ile_daje_jedzenie() {
        return ile_daje_jedzenie;
    }

    public int ile_rośnie_jedzenie() {
        return ile_rośnie_jedzenie;
    }

    public float koszt_tury() {
        return koszt_tury;
    }

    public float pr_powielenia() {
        return pr_powielenia;
    }

    public float ułamek_energii_rodzica() {
        return ułamek_energii_rodzica;
    }

    public float pr_usunięcia_instr() {
        return pr_usunięcia_instr;
    }

    public float pr_dodania_instr() {
        return pr_dodania_instr;
    }

    public float pr_zmiany_instr() {
        return pr_zmiany_instr;
    }

    public float limit_powielania() {
        return limit_powielania;
    }

    public int co_ile_wypisz() {
        return co_ile_wypisz;
    }
}
